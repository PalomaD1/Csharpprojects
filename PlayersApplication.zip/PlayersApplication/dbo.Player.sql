﻿CREATE TABLE [dbo].[Player] (
    [_id]    INT        NOT NULL IDENTITY,
    [name]   NCHAR (10) NULL,
    [wins]   NCHAR (10) NULL,
    [losses] NCHAR (10) NULL,
    [ties]   NCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([_id] ASC)
);

