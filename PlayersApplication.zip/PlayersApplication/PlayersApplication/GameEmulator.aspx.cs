﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PlayersApplication
{
    public partial class GameEmulator : System.Web.UI.Page
    {
        Player _player = new Player();

        protected void Page_Load(object sender, EventArgs e)
        {


            if (HttpContext.Current.Session["player1"] != null)
            {
                Response.Redirect("SelectPlayer1.aspx", true);
            }

            else if (HttpContext.Current.Session["player2"] != null)
            {
                Response.Redirect("SelectPlayer2.aspx", true);
            }

            else
            {
                lblDisplayPlayer1.Text = "Player 1";
                lblDisplayPlayer2.Text = "Player 2";
                btnPlayer1Wins.Text = "Player 1" + " wins!";
                btnPlayer2Wins.Text = "Player 2" + " wins!";
                btnItsATie.Text = "It's a tie!";
            }
        }

        protected void btnPlayer1Wins_Click(object sender, EventArgs e)
        {
            _player.Name= Session["player1"].ToString();
            _player.UpdateWins(Session["player1"].ToString());
            _player.Name = Session["player2"].ToString();
            _player.UpdateLosses(Session["player2"].ToString());
            Server.Transfer("Scoreboard.aspx", true);
        }

        protected void btnPlayer2Wins_Click(object sender, EventArgs e)
        {
            _player.Name = Session["player2"].ToString();
            _player.UpdateWins(Session["player2"].ToString());
            _player.Name = Session["player1"].ToString();
            _player.UpdateLosses(Session["player1"].ToString());
            Server.Transfer("Scoreboard.aspx", true);
        }

        protected void btnItsATie_Click(object sender, EventArgs e)
        {
            _player.Name = Session["player1"].ToString();
            _player.UpdateTies(Session["player1"].ToString()); //call the update ties
            _player.Name = Session["player2"].ToString();
            _player.UpdateTies(Session["player2"].ToString()); //call update ties
            Server.Transfer("Scoreboard.aspx", true);
        }
    }
}