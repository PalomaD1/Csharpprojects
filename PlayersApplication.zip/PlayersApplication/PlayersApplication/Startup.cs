﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PlayersApplication.Startup))]
namespace PlayersApplication
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
