﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PlayersApplication
{
    public partial class SelectPlayer2 : System.Web.UI.Page
    {
        Player _player = new Player();

        protected void Page_Load(object sender, EventArgs e)
        {
             _player = new Player();
            _player.LoadDropDownList();

            if (drpPlayer.Items.Count == 0)
            {
                for (int i = 0; i < _player.PlayerList.Count; i++)
                {
                    drpPlayer.Items.Add(_player.PlayerList[i]);
                }
            }
        }

        protected void SelectPlayerTwo(object sender, EventArgs e)
        {
            Session["player2"] = drpPlayer.SelectedItem;
            Server.Transfer("MainMenu.aspx", true); //redirects to main page
        }
    }
}