﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PlayersApplication
{
    public class Player
    {
        public static string conStr=ConfigurationManager.ConnectionStrings["PlayerConnString"].ConnectionString;

        //read only for all fields
        private int id;//field for id

        public int Id
        {
            get { return id; }
        }
        private string name;//field for name

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

      
        private int wins; //field for wins

        public int Wins
        {
            get { return wins; }
        }
        private int losses;//field for losses

        public int Losses
        {
            get { return losses; }
        }
        private int ties;//field for ties

        public int Ties
        {
            get { return ties; }
        }

        //non default constructor for fields

          private List<string> data = new List<string>(); //code for data as a parameter for sql

        public List<string> Data
        {
            get { return data; }
            set { data = value; }
        }

         private List<string> _playerList = new List<string>(); //store player names in list

        public List<string> PlayerList //setter method for playerlist 
        {
            get { return _playerList; }
          
        }

        public Player(int id1, string name1, int wins1, int losses1, int ties1)
        {
            id = id1;
            name = name1;
            wins = wins1;
            losses = losses1;
            ties = ties1; //non default constructor 
        }

         public Player(string conString)
        {
            conStr = conString;

        }

         public Player()
         {
             // TODO: Complete member initialization
         }

        public void addPlayer()
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                String query = "INSERT INTO Player(_id, name, wins, losses, ties)" +
                    "Values (@_id,@name,@wins,@losses,@ties)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@_id", Id);
                    cmd.Parameters.AddWithValue("@name", Name);
                    cmd.Parameters.AddWithValue("@wins", Wins);
                    cmd.Parameters.AddWithValue("@losses", Losses);
                    cmd.Parameters.AddWithValue("@ties", Ties);
                    cmd.ExecuteNonQuery();
                }

            }
        }

          public void LoadData()
        {
            string query = "Select _id, name, wins, losses, ties from Player";
            using (SqlConnection conn = new SqlConnection(conStr))
            {
              

               SqlCommand cmd = new SqlCommand(query, conn);
                
                    conn.Open();
                    try
                    {
                        SqlDataReader rdr = cmd.ExecuteReader();
                   
                        while (rdr.Read())
                        {
                            data.Add(rdr["_id"] + "\t\t" + rdr["name"] + "\t\t" + rdr["wins"] + "\t\t" + rdr["losses"] + "\t\t" + rdr["ties"]);

                        }
                    }
                    catch (SqlException e)
                    {
                        Console.Write(e);
                    }
                    
                       
            }
        }

        public void LoadDropDownList()
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = "SELECT name from Player"; //to select player name

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    try
                    {
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {

                                _playerList.Add(rdr["name"].ToString());
                            }
                        }

                    }
                    catch (SqlException e)
                    {
                        Console.Write(e);
                    }
                    
                }
            }
        }


        public void UpdateLosses(string s)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = "Update Player set losses = losses+1 Where name = @name";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@name", Name);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void UpdateTies(string s)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = "Update Player set ties = ties+1 Where name = @name";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@name", Name);
                    cmd.ExecuteNonQuery();
                }
            }
        }



        public void UpdateWins(string s)
        {
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                string query = "Update Player Set wins = wins+1 Where name = @name";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@name", Name);
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}
    
