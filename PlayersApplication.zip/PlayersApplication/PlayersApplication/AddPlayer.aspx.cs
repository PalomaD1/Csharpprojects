﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace PlayersApplication
{
    public partial class AddPlayer : System.Web.UI.Page
    {
       
        Player _player;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            
            int wins = 0, id=0, losses=0, ties=0;

            _player = new Player(id, txtName.Text, wins, losses, ties);
            _player.addPlayer();
            Server.Transfer("MainMenu.aspx", true);


        }
    }
}