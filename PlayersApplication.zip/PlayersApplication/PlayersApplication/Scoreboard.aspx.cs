﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PlayersApplication
{
    public partial class Scoreboard : System.Web.UI.Page
    {
        

        Player _player = new Player();
        protected void Page_Load(object sender, EventArgs e)
        {
            _player.LoadData();
            _player.Data.Sort();
            for (int i = 0; i < _player.Data.Count; i++)
            {
                lstPlayer.Items.Add(_player.Data[i]);
            }
        }
    }
}