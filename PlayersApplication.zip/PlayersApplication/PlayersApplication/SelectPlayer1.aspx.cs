﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PlayersApplication
{
    public partial class SelectPlayer1 : System.Web.UI.Page
    {
        Player _player = new Player();

        protected void Page_Load(object sender, EventArgs e)
        {
             _player = new Player();
            _player.LoadDropDownList(); //loads the dropdown list for selecting

            if (drpPlayer.Items.Count == 0)
            {
                for (int i = 0; i < _player.PlayerList.Count; i++)
                {
                    drpPlayer.Items.Add(_player.PlayerList[i]);
                }
            }

        }

        protected void SelectPlayerOne(object sender, EventArgs e)
        {
            Session["player1"] = drpPlayer.SelectedItem; //save the session to dropdown list
            Server.Transfer("MainMenu.aspx", true);
        }
    }
}