﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Depreciation
{
    class Depreciation
    {
        private double _cost=1000; //The original cost of the asset as a double

public double Cost
{
  get { return _cost; }
  set { _cost = value; }
}



private double _salvage; //field variables

public double Salvage
{
    get { return _salvage; }
    set { _salvage = value; }
}
private int _usefulLife;

public int UsefulLife
{
    get { return _usefulLife; }
    set { _usefulLife = value; }
}
       

        public Depreciation(double Cost, int UsefulLife, double Salvage)
        {
            //non default constructor to initialize all fields
            _cost = Cost;
            _usefulLife = UsefulLife;
            _salvage = Salvage;
        }

        public Depreciation()
        {
            // TODO: Complete member initialization
        }

        public double CalculateDepreciationValue(int period){
            
            double depreciation=0, accuSalvage=0;
            int factor=2;

            for (int i = 1; i <= period; i++)
            {
                accuSalvage += depreciation;
                depreciation = ((Cost - accuSalvage) * factor) / UsefulLife;
            }

            return depreciation;    
                
                 
                       
                
         
           
           
                
            
          
        }

    }
}
