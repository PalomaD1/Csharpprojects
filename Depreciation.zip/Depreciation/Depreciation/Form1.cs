﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Depreciation
{
    public partial class MainForm : Form
    {
        Depreciation _depobj = new Depreciation();
    

        public MainForm()
        {
            InitializeComponent();
            // Adding the event handler in the constructor
            this.Shown += new EventHandler(MainForm_Shown);
            
          
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
          //  lstUsefulLife.SelectedIndex = 12; //selected index is 4, the 2th item
            lstUsefulLife.Text = "4"; //display 4 on startup  
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstUsefulLife_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            _depobj.Salvage = Double.Parse(txtSalvage.Text);
            _depobj.Cost = Double.Parse(txtCost.Text);
      
             string selected = lstUsefulLife.Text;
            _depobj.UsefulLife = int.Parse(selected); //the useful life is set to 4
         
            txtDepreciation.AppendText("Year\tDepreciation");
            txtDepreciation.AppendText(Environment.NewLine);

            for (int i = 1; i <= _depobj.UsefulLife; i++)
            {
                txtDepreciation.AppendText(i +"\t$" + string.Format("{0:0.00}", _depobj.CalculateDepreciationValue(i)) + Environment.NewLine);
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

      /* private void txtSalvage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back) )) //accepts only numeric and backspace
                e.Handled = true;
        }

        private void txtCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        } */

        private void _txtSalvage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
            else if(!char.IsDigit(e.KeyChar)) {
                e.Handled = true;

            } else if (e.KeyChar != '.'){
                 e.Handled = true;
            } else 
            {
                e.Handled = false;
            }
            txtSalvage.Refresh();
        }

        private void _txtCost_KeyPress(object sender, KeyPressEventArgs e)
        {
             if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
            else if(!char.IsDigit(e.KeyChar)) {
                e.Handled = true;

            } else if (e.KeyChar != '.'){
                 e.Handled = true;
            } else 
            {
                e.Handled = false;
            }
             txtSalvage.Refresh();
        }

        private void txtSalvage_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void txtDepreciation_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
