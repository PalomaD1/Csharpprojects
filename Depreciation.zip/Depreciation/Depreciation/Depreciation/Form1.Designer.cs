﻿namespace Depreciation
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AssetLabel = new System.Windows.Forms.Label();
            this.UsefulLifeLabel = new System.Windows.Forms.Label();
            this.SalvageValueLabel = new System.Windows.Forms.Label();
            this.DepreciationScheduleLabel = new System.Windows.Forms.Label();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtDepreciation = new System.Windows.Forms.TextBox();
            this.txtSalvage = new System.Windows.Forms.TextBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.lstUsefulLife = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // AssetLabel
            // 
            this.AssetLabel.AutoSize = true;
            this.AssetLabel.Location = new System.Drawing.Point(30, 26);
            this.AssetLabel.Name = "AssetLabel";
            this.AssetLabel.Size = new System.Drawing.Size(60, 13);
            this.AssetLabel.TabIndex = 0;
            this.AssetLabel.Text = "Asset Cost:";
            // 
            // UsefulLifeLabel
            // 
            this.UsefulLifeLabel.AutoSize = true;
            this.UsefulLifeLabel.Location = new System.Drawing.Point(139, 26);
            this.UsefulLifeLabel.Name = "UsefulLifeLabel";
            this.UsefulLifeLabel.Size = new System.Drawing.Size(60, 13);
            this.UsefulLifeLabel.TabIndex = 1;
            this.UsefulLifeLabel.Text = "Useful Life:";
            // 
            // SalvageValueLabel
            // 
            this.SalvageValueLabel.AutoSize = true;
            this.SalvageValueLabel.Location = new System.Drawing.Point(250, 26);
            this.SalvageValueLabel.Name = "SalvageValueLabel";
            this.SalvageValueLabel.Size = new System.Drawing.Size(79, 13);
            this.SalvageValueLabel.TabIndex = 2;
            this.SalvageValueLabel.Text = "Salvage Value:";
            // 
            // DepreciationScheduleLabel
            // 
            this.DepreciationScheduleLabel.AutoSize = true;
            this.DepreciationScheduleLabel.Location = new System.Drawing.Point(30, 155);
            this.DepreciationScheduleLabel.Name = "DepreciationScheduleLabel";
            this.DepreciationScheduleLabel.Size = new System.Drawing.Size(118, 13);
            this.DepreciationScheduleLabel.TabIndex = 3;
            this.DepreciationScheduleLabel.Text = "Depreciation Schedule:";
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(23, 354);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(210, 32);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "Display Depreciation Schedule";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(292, 356);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(81, 30);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtDepreciation
            // 
            this.txtDepreciation.Location = new System.Drawing.Point(33, 181);
            this.txtDepreciation.Multiline = true;
            this.txtDepreciation.Name = "txtDepreciation";
            this.txtDepreciation.ReadOnly = true;
            this.txtDepreciation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDepreciation.Size = new System.Drawing.Size(294, 111);
            this.txtDepreciation.TabIndex = 6;
            this.txtDepreciation.TextChanged += new System.EventHandler(this.txtDepreciation_TextChanged);
            // 
            // txtSalvage
            // 
            this.txtSalvage.Location = new System.Drawing.Point(253, 50);
            this.txtSalvage.Name = "txtSalvage";
            this.txtSalvage.Size = new System.Drawing.Size(74, 20);
            this.txtSalvage.TabIndex = 7;
            this.txtSalvage.Text = "100";
            this.txtSalvage.TextChanged += new System.EventHandler(this.txtSalvage_TextChanged);
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(23, 50);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(93, 20);
            this.txtCost.TabIndex = 8;
            this.txtCost.Text = "1000";
            this.txtCost.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lstUsefulLife
            // 
            this.lstUsefulLife.FormattingEnabled = true;
            this.lstUsefulLife.Items.AddRange(new object[] {
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.lstUsefulLife.Location = new System.Drawing.Point(143, 50);
            this.lstUsefulLife.Name = "lstUsefulLife";
            this.lstUsefulLife.Size = new System.Drawing.Size(90, 69);
            this.lstUsefulLife.Sorted = true;
            this.lstUsefulLife.TabIndex = 9;
            this.lstUsefulLife.SelectedIndexChanged += new System.EventHandler(this.lstUsefulLife_SelectedIndexChanged);
            // 
            // MainForm
            // 
            this.AcceptButton = this.btnDisplay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 412);
            this.Controls.Add(this.lstUsefulLife);
            this.Controls.Add(this.txtCost);
            this.Controls.Add(this.txtSalvage);
            this.Controls.Add(this.txtDepreciation);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.DepreciationScheduleLabel);
            this.Controls.Add(this.SalvageValueLabel);
            this.Controls.Add(this.UsefulLifeLabel);
            this.Controls.Add(this.AssetLabel);
            this.Name = "MainForm";
            this.Text = "Depreciation Calculator";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AssetLabel;
        private System.Windows.Forms.Label UsefulLifeLabel;
        private System.Windows.Forms.Label SalvageValueLabel;
        private System.Windows.Forms.Label DepreciationScheduleLabel;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtDepreciation;
        private System.Windows.Forms.TextBox txtSalvage;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.ListBox lstUsefulLife;
    }
}

