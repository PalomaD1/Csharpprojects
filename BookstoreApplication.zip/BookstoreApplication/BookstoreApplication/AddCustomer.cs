﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookstoreApplication
{
    public partial class AddCustomer : Form
    {
        private Customer _customer;

      internal Customer Customer
        {
            get { return _customer; }
            set { _customer = value; }
        }
        string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        string _city;

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        string _prov;

        public string Prov
        {
            get { return _prov; }
            set { _prov = value; }
        }
        string _postal;

        public string Postal
        {
            get { return _postal; }
            set { _postal = value; }
        }
   
        public AddCustomer()
        {
            InitializeComponent();
        }

        private void txtFN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void txtLN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void txtCity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void txtProv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void txtAd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && !Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void txtPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsControl(e.KeyChar) && Char.IsDigit(e.KeyChar) && !Char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && !Char.IsWhiteSpace(e.KeyChar))
                e.Handled = true;
            base.OnKeyPress(e);
        }

        private void OnSubmit(object sender, EventArgs e)
        {
         
            this.FirstName = txtFN.Text;
            this.LastName = txtLN.Text;
            this.Address = txtAd.Text;
            this.City = txtCity.Text;
            this.Prov = txtProv.Text;
            this.Postal = txtPostal.Text;


            _customer = new Customer(this.FirstName, this.LastName, this.Address, this.City, this.Prov, this.Postal);
            this.Close();

        }
        public override string ToString()
        {
            return _firstName + "\t\t" + _lastName + "\t\t" + _address + "\t" + _city + "\t" + _prov + "\t " + _postal;
        }
        private void OnLoad(object sender, EventArgs e)
        {
            txtFN.Text = "";
            txtLN.Text = "";
            txtAd.Text = "";
            txtCity.Text = "";
            txtProv.Text = "";
            txtPostal.Text = "";
        }

        private void txtFN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
