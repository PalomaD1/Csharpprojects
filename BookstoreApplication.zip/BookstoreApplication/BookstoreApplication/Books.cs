﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookstoreApplication
{
    public class Books
    {
        //field variables
        private string _title; //title

        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        private string _author;//author

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }
        private string _isbn; //isbn

        public string Isbn
        {
            get { return _isbn; }
            set { _isbn = value; }
        }
        private string _storeid; //store id

        public string Storeid
        {
            get { return _storeid; }
            set { _storeid = value; }
        }
        private string _publisher;//publisher

        public string Publisher
        {
            get { return _publisher; }
            set { _publisher = value; }
        }

        public Books(string storeid, string title, string author, string publisher, string isbn)
        {
            _title = title;
            _publisher = publisher;
            _isbn = isbn;
            _storeid = storeid;
            _author = author;
        }

        public Books()
        {
            // TODO: Complete member initialization
        }

        public override string ToString()
        {
            string input = _storeid + "\t" + _title + "\t\t" + _author + "\t\t" + _publisher + "\t" + _isbn;
            char[] separator = new char[] { '\t' };
            string[] result1 = input.Split(separator, StringSplitOptions.None);
             
            string[] result2 = input.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            // result2 == new string[] { "x", "y", "z" }
            string result = string.Join("\t", result2);
            return result;
        }

    }
}
