﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; //required imports 

namespace BookstoreApplication
{
    public partial class BooksForm : Form

    {
        List<Books> _bookList;//list of type book, this is an araylist
        Books _books;
        AddBookForm _addBooks;
        CustomerForm _csform;
        DialogResult result;


        private BooksContact _contact;

        internal BooksContact Contact
        {
            get { return _contact; }
            set { _contact = value; }
        }

        string fileName;

        //create field variables

        FileStream fileStream;

        public BooksForm()
        {
            InitializeComponent();
            _contact = new BooksContact();
            _bookList = new List<Books>();
            _addBooks = new AddBookForm();
        }


      
           

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void deleteBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
             int selected = listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(selected); //remove the item at the selected index 
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //create a new object of the form
          

            DialogResult result = _addBooks.ShowDialog();
       
                _books = new Books();
                _books = _addBooks.Books;


                _bookList.Add(_books);

                listBox1.Items.Add(_books.ToString());


                listBox1.Refresh();
        

        }

        private void openListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "txt files (*.txt)|*.txt";
            var imagePath = System.IO.Path.Combine(Application.StartupPath, "books");
            openFileDialog1.InitialDirectory = imagePath;
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                _contact.ReadFromFile(fileName); //calls the readfromfile method of contact calss and takes the filename as a parameter
                foreach (Books person in _contact)
                {
                    _bookList.Add(person);
                    listBox1.Items.Add(person.ToString());
                }
            } 
        }

        private void saveListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.InitialDirectory =
                 Path.Combine(Path.GetDirectoryName(Directory.GetCurrentDirectory())); ;
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = openFileDialog1.FileName;
                _contact.WriteToFile(fileName);
            } 
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }

     

        public void setForm(AddBookForm form)
        {
            _addBooks = form;

        }

        private void BooksForm_Load(object sender, System.EventArgs e)
        {
            AddBookForm addform = new AddBookForm();
            //add items from first form to listbox

        }

        private void onShow(object sender, EventArgs e)
        {
            foreach (Books books in _contact)
            {
                listBox1.Items.Add(books.ToString());
            }
        }

        private void OnSortList(object sender, EventArgs e)
        {
            _bookList.Sort();
            listBox1.Items.Clear();
            //adding all the elements of the array
            listBox1.Items.AddRange(_bookList.ToArray());
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            _csform = new CustomerForm();
            _csform.Show();
        }

        private void OnDoubleClick(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
           
            _addBooks=new AddBookForm();
            listBox1.Items.RemoveAt(index); //deletes the item from the listbox
            DialogResult result = _addBooks.ShowDialog();

            _books = new Books();
            _books = _addBooks.Books;


            _bookList.Add(_books);

            listBox1.Items.Add(_books.ToString());


            listBox1.Refresh();
        
        



 
         
            }




        


      
 
        }

    }


