﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookstoreApplication
{
    class Customer
    {
        string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        string _city;

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        string _prov;

        public string Prov
        {
            get { return _prov; }
            set { _prov = value; }
        }
        string _postal;

        public string Postal
        {
            get { return _postal; }
            set { _postal = value; }
        }


        public Customer(string firstName, string lastName, string address, string city, string prov, string postal)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Address = address;
            this.City = city;
            this.Prov = prov;
            this.Postal = postal;

        }

        public Customer()
        {
            // TODO: Complete member initialization
        }

        public override string ToString()
        {
            return FirstName + "\t\t" + LastName + "\t\t" + Address + "\t" + City + "\t" + Prov + "\t " + Postal;
        }

    }
}
