﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookstoreApplication
{
    public partial class AddBookForm : Form
    {

        private Books _books;//list of type student, this is an araylist

        public Books Books
        {
            get { return _books; }
            set { _books = value; }
        }
       
        public AddBookForm()
        {
            InitializeComponent();
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //initialize the field varialbes from the student class and send the values to the second class

            _books = new Books();
            string id = _books.Storeid;
            id= txtID.Text;
            string title = _books.Title;
            title = txtTitle.Text;
            string author = _books.Author;
            author = txtAuthor.Text;
            string publisher = _books.Publisher;
             publisher = txtPublisher.Text;
             string isbn = _books.Isbn;
             isbn = txtISBN.Text;


            _books = new Books(id + "\t", title + "\t",author + "\t", publisher + "\t", isbn + "\t");
            this.Close();
            
            
        
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTitle_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            } //allow only alphabets 
        }

        private void txtAuthor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            } //allow only alphabets 
        }

        private void txtPublisher_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            } //allow only alphabets 
        }

        private void txtISBN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && !e.KeyChar.Equals('.'))
            {
                e.Handled = true;//validate numeric inputs 
            }
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && !e.KeyChar.Equals('.'))
            {
                e.Handled = true;//validate numeric inputs 
            }

        }

        private void txtISBN_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddBookForm_DoubleClick(object sender, EventArgs e)
        {






        }




    }
}
