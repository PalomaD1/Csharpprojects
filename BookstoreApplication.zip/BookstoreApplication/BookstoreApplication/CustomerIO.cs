﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace BookstoreApplication 
{
    class CustomerIO : IEnumerable<Customer>
    {

        OpenFileDialog ofd = new OpenFileDialog();
        SaveFileDialog sfd = new SaveFileDialog();
        List<Customer> _customerList;

      public List<Customer> CustomerList
        {
            get { return _customerList; }
            set { _customerList = value; }
        }

        public CustomerIO()
        {
            _customerList = new List<Customer>();

        }

        public void Write()
        {

            sfd.Filter = "txt files (*.txt)|*.txt";
            sfd.InitialDirectory =
                 Path.Combine(Path.GetDirectoryName(Directory.GetCurrentDirectory())); ;
            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = ofd.FileName;

                FileStream fileStream = null;
                StreamWriter streamWriter = null;
                try
                {
                    fileStream = new FileStream(fileName, FileMode.Create, FileAccess.Write);

                    streamWriter = new StreamWriter(fileStream);

                    foreach (Customer cust in _customerList)
                    {
                        streamWriter.WriteLine(cust.FirstName + "," + cust.LastName + "," + cust.Address + "," + cust.City + " ," + cust.Prov + " ," + cust.Postal);
                    }

                    Console.WriteLine("Write is done");
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(fileName + " not found.", "File Not Found");
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message, "IOException");
                }
                finally
                {
                    if (streamWriter != null)
                    {
                        streamWriter.Close(); // closing the writer
                    }
                }
            }

        }


        public void Read(string fileName)
        {

            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read);

                StreamReader streamReader = new StreamReader(fileStream);

                while (streamReader.Peek() != -1)
                {

                    string record = streamReader.ReadLine();

                    string[] fields = record.Split(',');

                    _customerList.Add(new Customer(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]));

                }

                Console.WriteLine("The Read operation has ended");
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(fileName + " not found.", "File Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");
            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }
        }


        public Customer this[int idx]
        {
            get
            {
                return _customerList.ElementAt(idx);
            }
            set
            {

                _customerList.Add(value);
            }
        }



        public IEnumerator<Customer> GetEnumerator()
        {
            return _customerList.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

    }



}
