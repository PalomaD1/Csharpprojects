﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookstoreApplication
{
    class BooksContact : IEnumerable<Books>
    {
         //Dynamic Array
        private List<Books> _contactList;

        public List<Books> ContactList
        {
            get { return _contactList; }
            set { _contactList = value; }
        }

        Books _books;


        public BooksContact()
        {
            _contactList = new List<Books>();
        }

        //indexer
        public Books this[int idx]
        {
            get
            {// Return desired data.
                return _contactList.ElementAt(idx);
            }
            set
            {// Set desired data using the “value”parameter}

                _contactList.Add(value);
            }
        }

        //this method reads from the file
        public void ReadFromFile(string path)
        {
            _books=new Books();
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read);

                StreamReader streamReader = new StreamReader(fileStream);

                while (streamReader.Peek() != -1)
                {
                    _books = new Books();

                    string record = streamReader.ReadLine();
                    string[] fields = record.Split(',');
                  


                    _contactList.Add(new Books(fields[0] + "\t", fields[1] + "\t", fields[2] + "\t", fields[3] + "\t", fields[4] + "\t"));

                }




                Console.WriteLine("The Read operation has ended");

            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(path + " not found.", "File Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");

            }
            finally
            {
                if (fileStream != null)
                {
                    fileStream.Close();
                }
            }


        }


        // this method writes the records to the file
        public void WriteToFile(string path)
        {

            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);

                streamWriter = new StreamWriter(fileStream);


                foreach (Books books in _contactList)
                {
                    streamWriter.WriteLine(books.Storeid + "," + books.Title + "," + books.Author + "," + books.Publisher + "," + books.Isbn);
                }

                Console.WriteLine("Write is done");

            }
            catch (FileNotFoundException)
            {
                MessageBox.Show(path + " not found.", "File Not Found");
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "IOException");

            }
            finally
            {
                if (streamWriter != null)
                {

                    streamWriter.Close(); // closing the writer
                }
            }

        }




        public IEnumerator<Books> GetEnumerator()
        {
            return _contactList.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
