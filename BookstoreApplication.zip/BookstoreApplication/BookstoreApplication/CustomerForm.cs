﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BookstoreApplication 
{
    public partial class CustomerForm : Form
    {
        DialogResult result; 
        CustomerIO _customerIO;

        internal CustomerIO CustomerIO
        {
            get { return _customerIO; }
            set { _customerIO = value; }
        }
        string fileName;


        string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        string _city;

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        string _prov;

        public string Prov
        {
            get { return _prov; }
            set { _prov = value; }
        }
        string _postal;

        public string Postal
        {
            get { return _postal; }
            set { _postal = value; }
        }


        AddCustomer addCust;

        public CustomerForm()
        {
            InitializeComponent();
            addCust = new AddCustomer();
            _customerIO = new CustomerIO();
        }

        private void OnLoad(object sender, EventArgs e)
        {

       

        }

        private void OnClick(object sender, EventArgs e)
        {

        }

        private void OnOpen(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            openFileDialog.Filter = "txt files (*.txt)|*.txt";
            var imagePath = System.IO.Path.Combine(Application.StartupPath, "customer");
            openFileDialog.InitialDirectory = imagePath;
          
            DialogResult result = openFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                fileName = openFileDialog.FileName;
            }
            _customerIO.Read(fileName);

            AddToListBox();
        }


        private void onShow(object sender, EventArgs e)
        {
            foreach (Customer cust in _customerIO)
            {
                listBox.Items.Add(cust.ToString());
            }
        }

        public void AddToListBox()
        {
            try
            {

                foreach (Customer cust in _customerIO.CustomerList)
                {
                    listBox.Items.Add(cust.ToString());
                }

            }
            catch (NullReferenceException ex)
            {
                listBox.Items.Add("");
            }
        

        }

        private void OnSave(object sender, EventArgs e)
        {
            _customerIO.Write();
        }

        private void OnDelete(object sender, EventArgs e)
        {

            int i = listBox.SelectedIndex;
            listBox.Items.RemoveAt(i);
            _customerIO.CustomerList.RemoveAt(i);

        }

        public void Add()
        {


        }


        private void OnAdd(object sender, EventArgs e)
        {


            int index = listBox.SelectedIndex;

            result = addCust.ShowDialog();
            if (result == DialogResult.OK)
            {
           
                _customerIO.CustomerList.Add(addCust.Customer);
                AddToListBox();
                listBox.Refresh();
            }
    
           
           


        }
        private void OnExit(object sender, EventArgs e)
        {
            Application.Exit();
        }

      

        private void OnDoubleClick(object sender, EventArgs e)
        {
            
            int index = listBox.SelectedIndex;

      result = addCust.ShowDialog();
          if (result == DialogResult.OK)
            {
     
            
                listBox.Items.RemoveAt(index);
                _customerIO.CustomerList.RemoveAt(index);


                _customerIO.CustomerList.Add(addCust.Customer);


                listBox.Items.Add(addCust.Customer.ToString());
   
                listBox.Refresh();
            }

        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
