﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessingGameApplicationV2
{
    public partial class mainForm : Form
    {
        GuessingGame _gameObj = new GuessingGame(0, 10);
        

        
        public const int DEFAULT_LOWER_BOUND = 0;
        public const int DEFAULT_UPPER_BOUND = 10; //upper bound integer

        public mainForm()
        {
            InitializeComponent(); //when the form is created
            _gameObj = new GuessingGame(); //calls the behavior of the default constructor from GuessingGame.cs
         
          lblRandomValue.Text = _gameObj.NumberToGuess.ToString(); //converts the random value to a string to print it out
        }

        private void txtGuess_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtHint_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            int userGuess = int.Parse(txtGuess.Text); //local variable to check against random value and parse the user input to integer
            GuessHint hint = _gameObj.CheckGuess(userGuess);

            switch (hint)
            {
                
                case  GuessHint.TooLow: //takes the enum.firstvalue
                    txtHint.Text = "Guess is too low"; //displays it in the textbox
                    break;
                case GuessHint.JustRight:
                    txtHint.Text = "Guess is right";
                    break;
                 case GuessHint.TooHigh:
                    txtHint.Text = "Guess is too high";
                        // return GuessHint.TooHigh; 
                         break; 
                default:
                    
                    break;

            }
            
        }
    }
}
