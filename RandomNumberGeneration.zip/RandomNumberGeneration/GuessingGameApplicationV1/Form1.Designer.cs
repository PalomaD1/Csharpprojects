﻿namespace GuessingGameApplicationV2
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTText = new System.Windows.Forms.Label();
            this.txtGuess = new System.Windows.Forms.TextBox();
            this.txtHint = new System.Windows.Forms.TextBox();
            this.btnGuess = new System.Windows.Forms.Button();
            this.lblRandomValue = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTText
            // 
            this.lblTText.AutoSize = true;
            this.lblTText.Location = new System.Drawing.Point(24, 25);
            this.lblTText.Name = "lblTText";
            this.lblTText.Size = new System.Drawing.Size(40, 13);
            this.lblTText.TabIndex = 0;
            this.lblTText.Text = "Guess:";
            // 
            // txtGuess
            // 
            this.txtGuess.Location = new System.Drawing.Point(79, 22);
            this.txtGuess.Name = "txtGuess";
            this.txtGuess.Size = new System.Drawing.Size(117, 20);
            this.txtGuess.TabIndex = 1;
            this.txtGuess.TextChanged += new System.EventHandler(this.txtGuess_TextChanged);
            // 
            // txtHint
            // 
            this.txtHint.Location = new System.Drawing.Point(27, 77);
            this.txtHint.Multiline = true;
            this.txtHint.Name = "txtHint";
            this.txtHint.Size = new System.Drawing.Size(319, 66);
            this.txtHint.TabIndex = 2;
            this.txtHint.TextChanged += new System.EventHandler(this.txtHint_TextChanged);
            // 
            // btnGuess
            // 
            this.btnGuess.Location = new System.Drawing.Point(259, 18);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(87, 26);
            this.btnGuess.TabIndex = 3;
            this.btnGuess.Text = "Enter Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // lblRandomValue
            // 
            this.lblRandomValue.AutoSize = true;
            this.lblRandomValue.Location = new System.Drawing.Point(44, 173);
            this.lblRandomValue.Name = "lblRandomValue";
            this.lblRandomValue.Size = new System.Drawing.Size(0, 13);
            this.lblRandomValue.TabIndex = 4;
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 242);
            this.Controls.Add(this.lblRandomValue);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.txtHint);
            this.Controls.Add(this.txtGuess);
            this.Controls.Add(this.lblTText);
            this.Name = "mainForm";
            this.Text = "Guessing Game V1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTText;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.TextBox txtHint;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Label lblRandomValue;
    }
}

