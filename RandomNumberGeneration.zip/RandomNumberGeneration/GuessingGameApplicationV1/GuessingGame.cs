﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuessingGameApplicationV2
{
    

    public enum GuessHint
    {
        TooLow=-1,
        JustRight=0,
        TooHigh=1, //my enum
    }
    public struct GuessRange
    {

        ///will be having 2 members, an integer for lower bound and upper bound
        private int _lowerBound; //lower bound integer
      
        public int LowerBound
        {
            get { return _lowerBound; }
            set { _lowerBound = value; }
        }
        private int _upperBound; //upperbound integer
        //constructor that allows clients to intitialize both upper and lower bound in one stmt using an operator
        //structures can have constructors but not a default constructor
        public GuessRange(int lower, int upper)
        {
            _lowerBound = lower;
            _upperBound = upper;
        }
    }
    
    // Represents the business logic of the program, the simple game of generating a random 
    // number between a lower and upper limit and checking guess against that number
    
    class GuessingGame
    {
        public  const int DEFAULT_LOWER_BOUND=0;
        public const int DEFAULT_UPPER_BOUND = 10; //upper bound integer


        
        
        // The lower bound for allowed guesses
        
        private int _lowerBound;

        
        // The upper bound for allowed guesses

        private int _upperBound;

        public int UpperBound
        {
            get { return _upperBound; }
            set { _upperBound = value; }
        }

     
        // The number the game is generating and that is supposed to be guessed

        private int _numberToGuess;

        public int NumberToGuess
        {
            get { return _numberToGuess; }
          //we get rid of the setter to make this a read only property for this member of the class 
        }
        //read only property means there is no setter just getter

        // A random generator that is used to generate the number to guess
        
        private Random _randomGen;

        // Constructor of the class that forces clients to provide lower and upper bounds. As soon as
        // the constructor is called and the game is thus created the number to guess has been generated
        //the lower bound for acceptable guesses
        //the upper bound for acceptable guesses
        public GuessingGame(int lowerBound, int upperBound) //two argument constructor
        {
            //initialize the lower and upper bounds
            _lowerBound = lowerBound;
            _upperBound = upperBound;

            //generate a random integer between the two bounds
            _randomGen = new Random(); //random value created
            _numberToGuess = _randomGen.Next(_lowerBound, _upperBound); //random value generated, takes the lowerbound and upperbound
        }

        public GuessingGame()
        {
            _lowerBound = DEFAULT_LOWER_BOUND;
            _upperBound = DEFAULT_UPPER_BOUND;
        }
       
        // Checks a given guess against the number to guess as established by the game
        
        //the guess to be checked returns
        //    +1 if the given guess is too high
        //     -1 if the given guess is too low
        //     0 if the given guess is equal to the number to guess 
        //
        public GuessHint CheckGuess(int guess)
        {
            if (guess == _numberToGuess) //equal when user guess equals random value
            {
                return GuessHint.JustRight;
                
            }
            else if (guess > _numberToGuess) //too high guess from user
            {
                return GuessHint.TooHigh;
            }
            else //too low
            {
                return GuessHint.TooLow;
            }






         
        
        }

    }
}


